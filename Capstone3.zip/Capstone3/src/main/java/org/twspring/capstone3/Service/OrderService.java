package org.twspring.capstone3.Service;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.twspring.capstone3.Api.ApiException;
import org.twspring.capstone3.Model.*;
import org.twspring.capstone3.Repository.ArtEnthusiastRepository;
import org.twspring.capstone3.Repository.ArtPieceForSaleRepository;
import org.twspring.capstone3.Repository.DeliveryCompanyRepository;
import org.twspring.capstone3.Repository.OrderRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;
    private final ArtEnthusiastRepository artEnthusiastRepository;
    private final ArtPieceForSaleRepository artPieceForSaleRepository;
    private final DeliveryCompanyRepository deliveryCompanyRepository;

    public List<ArtOrder> getAllOrders() { //for shop/for user
        return orderRepository.findAll();
    }

    public void addOrder( Integer artEnthusiastId, ArtOrder artOrder){ //add to order. edit so it's automatically created when ordering a piece with no completed order

        ArtEnthusiast artEnthusiast = artEnthusiastRepository.getArtEnthusiastById(artEnthusiastId);
        if (artEnthusiast==null){
            throw new ApiException("Art Enthusiast with id "+artEnthusiastId+" does not exist");
        }
        orderRepository.save(artOrder);
        artEnthusiast.getArtOrders().add(artOrder);
    }

    //EXTRA56
    public void addArtPieceToOrder(Integer artEnthusiastId, Integer artOrderId, Integer artPieceForSaleId){
        ArtOrder artOrder = orderRepository.findOrderById(artOrderId);
        if(artOrder==null){
            throw new ApiException("Art order with ID "+artOrderId+" does not exist");
        }

        ArtEnthusiast artEnthusiast = artEnthusiastRepository.getArtEnthusiastById(artEnthusiastId);
        if(artEnthusiast==null){
            throw new ApiException("Art enthusiast with ID "+artOrderId+" does not exist");
        }

        ArtPieceForSale artPieceForSale = artPieceForSaleRepository.findArtPieceForSaleById(artPieceForSaleId);
        if(artPieceForSale==null){
            throw new ApiException("Art piece for Sale with ID "+artOrderId+" does not exist");
        }
        if(artOrder.getStatus()!=ArtOrder.Status.ACTIVE){
            throw new ApiException("Art order status is not active, create a new order");
        }
        artOrder.setTotalPrice(artOrder.getTotalPrice()+artPieceForSale.getPrice());
        artOrder.getArtPieceForSale().add(artPieceForSale);
        orderRepository.save(artOrder);
    }

    //EXTRA
    public void removeFromOrder(Integer artEnthusiastId, Integer artOrderId, Integer artPieceForSaleId){
        ArtOrder artOrder = orderRepository.findOrderById(artOrderId);
        if(artOrder==null){
            throw new ApiException("Art order with ID "+artOrderId+" does not exist");
        }

        ArtEnthusiast artEnthusiast = artEnthusiastRepository.getArtEnthusiastById(artEnthusiastId);
        if(artEnthusiast==null){
            throw new ApiException("Art enthusiast with ID "+artOrderId+" does not exist");
        }
        ArtPieceForSale artPieceForSale = artPieceForSaleRepository.findArtPieceForSaleById(artPieceForSaleId);
        if(artPieceForSale==null){
            throw new ApiException("Art piece for Sale with ID "+artOrderId+" does not exist");
        }
        if(artOrder.getStatus()!=ArtOrder.Status.ACTIVE){
            throw new ApiException("Art order status is not active, create a new order");
        }
        artOrder.setTotalPrice(artOrder.getTotalPrice()-artPieceForSale.getPrice());
        artOrder.getArtPieceForSale().remove(artPieceForSale);
        orderRepository.save(artOrder);
    }

    public void pickDeliveryCompany(Integer artEnthusiastId, Integer artOrderId, Integer deliveryCompanyId){
        ArtOrder artOrder = orderRepository.findOrderById(artOrderId);
        if(artOrder==null){
            throw new ApiException("Art order with ID "+artOrderId+" does not exist");
        }
        ArtEnthusiast artEnthusiast = artEnthusiastRepository.getArtEnthusiastById(artEnthusiastId);
        if(artEnthusiast==null){
            throw new ApiException("Art enthusiast with ID "+artEnthusiastId+" does not exist");
        }
        DeliveryCompany deliveryCompany= deliveryCompanyRepository.getDeliveryCompaniesById(deliveryCompanyId);
        if(deliveryCompany==null){
            throw new ApiException("Delivery company with ID "+deliveryCompanyId+" does not exist");
        }
        artOrder.setDeliveryCompany(deliveryCompany);
        orderRepository.save(artOrder);
    }

    public void checkoutOrder(Integer artEnthusiastId, Integer artOrderId){
        ArtOrder artOrder = orderRepository.findOrderById(artOrderId);
        if(artOrder==null){
            throw new ApiException("Art order with ID "+artOrderId+" does not exist");
        }

        ArtEnthusiast artEnthusiast = artEnthusiastRepository.getArtEnthusiastById(artEnthusiastId);
        if(artEnthusiast==null){
            throw new ApiException("Art enthusiast with ID "+artOrderId+" does not exist");
        }

        if(artOrder.getStatus()!=ArtOrder.Status.ACTIVE){
            throw new ApiException("Art order status is not active, create a new order");
        }
        if(artOrder.getDeliveryCompany()==null){
            throw new ApiException("You must pick a delivery company first");
        }
        artOrder.setStatus(ArtOrder.Status.SHIPPED);
        orderRepository.save(artOrder);
        //create Bill
        Bill bill = new Bill();
        bill.setProductsAmount(artOrder.getTotalPrice());
        bill.setShippingFee(artOrder.getDeliveryCompany().getDeliveryFee());
        artEnthusiast.getBills().add(bill);
        artOrder.setBill(bill);
    }


    public void updateArtOrderAsDelivered(Integer artOrderId){ //ADD SHIPPING AGENT
        ArtOrder artOrder = orderRepository.findOrderById(artOrderId);
        if(artOrder==null){
            throw new ApiException("Art order with ID "+artOrderId+" does not exist");
        }
        if(artOrder.getStatus()!=ArtOrder.Status.SHIPPED){
            throw new ApiException("Art order is not shipped");
        }
        artOrder.setStatus(ArtOrder.Status.DELIVERED);
    }


//    public void cancelOrder(Integer artEnthusiastId, Integer id){ //canceling removes it from the system
//        ArtOrder artOrder = orderRepository.findOrderById(id)
//                .orElseThrow(() -> new ApiException("ORDER NOT FOUND"));
//        orderRepository.delete(artOrder);
//    }
}
