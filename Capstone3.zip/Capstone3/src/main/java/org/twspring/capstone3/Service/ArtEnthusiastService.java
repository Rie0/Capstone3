package org.twspring.capstone3.Service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.twspring.capstone3.Model.ArtEnthusiast;
import org.twspring.capstone3.Model.Exhibition;
import org.twspring.capstone3.Model.ExhibitionTicket;
import org.twspring.capstone3.Repository.ArtEnthusiastRepository;
import org.twspring.capstone3.Api.ApiException;
import org.twspring.capstone3.Repository.ExhibitionRepository;
import org.twspring.capstone3.Repository.ExhibitionTicketRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ArtEnthusiastService {
    private final ArtEnthusiastRepository artEnthusiastRepository;
    private final ExhibitionRepository exhibitionRepository;
    private final ExhibitionTicketRepository exhibitionTicketRepository;

    public List<ArtEnthusiast> getAllArtEnthusiasts() {
        return artEnthusiastRepository.findAll();
    }

    public void addArtEnthusiast(ArtEnthusiast artEnthusiast) {
        artEnthusiastRepository.save(artEnthusiast);
    }

    public void updateArtEnthusiast(Integer id, ArtEnthusiast artEnthusiast) {
        ArtEnthusiast existingArtEnthusiast = artEnthusiastRepository.findById(id).orElseThrow(() ->
                new ApiException("Art Enthusiast with id " + id + " not found")
        );
        existingArtEnthusiast.setUsername(artEnthusiast.getUsername());
        existingArtEnthusiast.setPassword(artEnthusiast.getPassword());
        existingArtEnthusiast.setEmail(artEnthusiast.getEmail());
//        existingArtEnthusiast.setUpdatedAt(artEnthusiast.getUpdatedAt());
        artEnthusiastRepository.save(existingArtEnthusiast);
    }

    public void deleteArtEnthusiast(Integer id) {
        ArtEnthusiast existingArtEnthusiast = artEnthusiastRepository.findById(id).orElseThrow(() ->
                new ApiException("Art Enthusiast with id " + id + " not found")
        );
        artEnthusiastRepository.delete(existingArtEnthusiast);
    }
    //EP
    public void cancelTicket(Integer ticketId, Integer enthusiastId) {
        // Find the ticket
        ExhibitionTicket ticket = exhibitionTicketRepository.findById(ticketId)
                .orElseThrow(() -> new ApiException("Ticket not found with id: " + ticketId));
        // Check if the ticket belongs to the art enthusiast
        if (!ticket.getArtEnthusiast().getId().equals(enthusiastId)) {
            throw new ApiException("This ticket does not belong to the art enthusiast.");}
        //check if cancellation is allowed based on date is before local date.now
        Exhibition exhibition = ticket.getExhibition();
        if (exhibition.getStartDate().isBefore(LocalDate.now())) {
            throw new ApiException("Cannot cancel ticket: the exhibition has already started.");}
        // Remove the ticket from the repository
        exhibitionTicketRepository.delete(ticket);
        // Decrement the current capacity of the exhibition
        exhibition.setCurrentCapacity(exhibition.getCurrentCapacity() - 1);
        exhibitionRepository.save(exhibition);
    }
}
