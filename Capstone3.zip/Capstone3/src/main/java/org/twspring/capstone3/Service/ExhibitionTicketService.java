package org.twspring.capstone3.Service;

import jakarta.persistence.criteria.CriteriaBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.twspring.capstone3.Api.ApiException;
import org.twspring.capstone3.Model.ArtEnthusiast;
import org.twspring.capstone3.Model.ExhibitionTicket;
import org.twspring.capstone3.Model.Exhibition;
import org.twspring.capstone3.Repository.ArtEnthusiastRepository;
import org.twspring.capstone3.Repository.ExhibitionRepository;
import org.twspring.capstone3.Repository.ExhibitionTicketRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ExhibitionTicketService {

    private final ExhibitionTicketRepository exhibitionTicketRepository;
    private final ArtEnthusiastRepository artEnthusiastRepository;
    private final ExhibitionRepository exhibitionRepository;



    public List<ExhibitionTicket> getAllExhibitionTickets() {
        return exhibitionTicketRepository.findAll();
    }

    //post
    //EP
    public void issueExhibitionTicket(Integer artEnthusiast_id, Integer exhibition_id) {
//        ArtEnthusiast ae = artEnthusiastRepository.getArtEnthusiastById(artEnthusiast_id);
//        Exhibition e = exhibitionRepository.findExhibitionById(exhibition_id);
//        if(ae == null){
//            throw new ApiException("Art Enthusiast not found");
//        }
//        if(e == null){
//            throw new ApiException("Exhibition not found");
//        }
//        exhibitionTicket.setArtEnthusiast(ae);
//        exhibitionTicket.setExhibition(e);
//        exhibitionTicketRepository.save(exhibitionTicket);
        // Retrieve the exhibition and art enthusiast
        Exhibition e = exhibitionRepository.findExhibitionById(exhibition_id);
        if (e == null) {
            throw new ApiException("Exhibition with id " + exhibition_id + " not found");
        }
        ArtEnthusiast enthusiast = artEnthusiastRepository.getArtEnthusiastById(artEnthusiast_id);
        if (enthusiast == null) {
            throw new ApiException("Art Enthusiast not found with id: " + artEnthusiast_id);
        }
        // Check if the exhibition is open
        if (!e.isOpen()) {
            throw new ApiException("Exhibition is not open for ticket sales.");
        }
        // Check if capacity allows for more tickets
        if (e.getCurrentCapacity() >= e.getMaxCapacity()) {
            throw new ApiException("Cannot purchase ticket: capacity reached.");
        }
        ExhibitionTicket ticket = new ExhibitionTicket();
        // Create and save the ticket
        ticket.setArtEnthusiast(enthusiast);
        ticket.setExhibition(e);
        ticket.setAmount(e.getTicketPrice());
        e.setCurrentCapacity(e.getCurrentCapacity() + 1);
        exhibitionTicketRepository.save(ticket);
        exhibitionRepository.save(e);
    }

    public void updateExhibitionTicket(Integer id, ExhibitionTicket exhibitionTicket) {
        ExhibitionTicket et = exhibitionTicketRepository.findExhibitionTicketById(id);
        if(et == null){
            throw new ApiException("Exhibition ticket not found");
        }
        et.setPurchaseDate(exhibitionTicket.getPurchaseDate());
//        et.setCreatedAt(exhibitionTicket.getCreatedAt());
//        et.setUpdatedAt(exhibitionTicket.getUpdatedAt());
        et.setAmount(exhibitionTicket.getAmount());
        exhibitionTicketRepository.save(et);
    }

    public void deleteExhibitionTicket(Integer id) {
        ExhibitionTicket et = exhibitionTicketRepository.findExhibitionTicketById(id);
        if(et == null){
            throw new ApiException("Exhibition ticket not found");}
        exhibitionTicketRepository.delete(et);
    }

}
